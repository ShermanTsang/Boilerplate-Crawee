module.exports = {
    twitterUsernameOrEmail: '8615008377440',
    twitterPassword: '4565999538',
}