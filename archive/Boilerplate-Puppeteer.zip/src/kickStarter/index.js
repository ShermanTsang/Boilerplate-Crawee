const puppeteer = require('puppeteer')
const {scrollPageToBottom} = require('puppeteer-autoscroll-down')

const config = {
    entranceUrl: 'https://pro.m.jd.com/wq/active/2NdsiNLZydnew1r48svHj6RXLjnd/index.html?babelChannel=ttt10&jrcontainer=h5&jrlogin=true&utm_source=Android_url_1641138818304&utm_medium=jrappshare&utm_term=wxfriends'
}
const user_agent = '--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36'
const options = {
    headless: false,
    args: ['--no-sandbox', user_agent]
}

puppeteer.launch(options).then(async browser => {
    const page = await browser.newPage()
    await page.goto(config.entranceUrl)
    await page.setJavaScriptEnabled(true)

    await page.evaluate(() => {
        window.scrollTo(0, 0)
    })
    await scrollPageToBottom(page, {})

    const selector = {
        list: '.rv',
        name: '.bgnUuL',
        description: '.cLAkeW'
    }
    await page.waitForSelector(selector.list)
    const elements = await page.$$eval(selector.list, elements => {
        const fields = [
            {key: 'name', selector: '.bgnUuL', valueAttribute: 'innerText', valueType: 'string'},
            {key: 'description', selector: '.cLAkeW', valueAttribute: 'innerText', valueType: 'string'},
            {key: 'progress', selector: '.izzIjE', valueAttribute: 'innerText', valueType: 'number'},
            {key: 'supporter_count', selector: '.kvUifV', valueAttribute: 'innerText', valueType: 'number'},
            {key: 'price', selector: '.eueXfw', valueAttribute: 'innerText', valueType: 'number'},
            {key: 'image_cover', selector: '.rHbdQ', valueAttribute: 'src', valueType: 'url'}
        ]
        const result = []
        elements.forEach(item => {
            const data = {}
            fields.forEach(fieldItem => {
                if (!item.querySelector(fieldItem.selector)) {
                    data[fieldItem.key] = '-'
                    return
                }

                if (fieldItem.valueType === 'number') {
                    data[fieldItem.key] = Number.parseInt(item.querySelector(fieldItem.selector)[fieldItem.valueAttribute])
                    return
                }
                data[fieldItem.key] = item.querySelector(fieldItem.selector)[fieldItem.valueAttribute]

            })
            result.push(data)
        })
        return result
    })
    console.log(elements)
})